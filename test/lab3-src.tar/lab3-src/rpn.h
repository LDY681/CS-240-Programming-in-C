
#include <stdio.h>

double rpn_eval(char * fileName, double x);

